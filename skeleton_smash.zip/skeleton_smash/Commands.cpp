#include <unistd.h>
#include <string.h>
#include <iostream>
#include <vector>
#include <sstream>
#include <sys/wait.h>
#include <iomanip>
#include "Commands.h"
#include <signal.h>

using namespace std;
const std::string WHITESPACE = " \n\r\t\f\v";

#if 0
#define FUNC_ENTRY()  \
  cout << __PRETTY_FUNCTION__ << " --> " << endl;

#define FUNC_EXIT()  \
  cout << __PRETTY_FUNCTION__ << " <-- " << endl;
#else
#define FUNC_ENTRY()
#define FUNC_EXIT()
#endif

string _ltrim(const std::string& s)
{
  size_t start = s.find_first_not_of(WHITESPACE);
  return (start == std::string::npos) ? "" : s.substr(start);
}

string _rtrim(const std::string& s)
{
  size_t end = s.find_last_not_of(WHITESPACE);
  return (end == std::string::npos) ? "" : s.substr(0, end + 1);
}

string _trim(const std::string& s)
{
  return _rtrim(_ltrim(s));
}
//receives cmd_line and an empty array of strings args. Separates the words in cmd_line into different array slots in args. Returns the number of words in cmdline.
int _parseCommandLine(const char* cmd_line, char** args) {
  FUNC_ENTRY()
  int i = 0;
  std::istringstream iss(_trim(string(cmd_line)).c_str());
  for(std::string s; iss >> s; ) {
    args[i] = (char*)malloc(s.length()+1);
    memset(args[i], 0, s.length()+1);
    strcpy(args[i], s.c_str());
    args[++i] = NULL;
  }
  return i;

  FUNC_EXIT()
}

bool _isBackgroundComamnd(const char* cmd_line) {
  const string str(cmd_line);
  return str[str.find_last_not_of(WHITESPACE)] == '&';
}

void _removeBackgroundSign(char* cmd_line) {
  const string str(cmd_line);
  // find last character other than spaces
  unsigned int idx = str.find_last_not_of(WHITESPACE);
  // if all characters are spaces then return
  if (idx == string::npos) {
    return;
  }
  // if the command line does not end with & then return
  if (cmd_line[idx] != '&') {
    return;
  }
  // replace the & (background sign) with space and then remove all tailing spaces.
  cmd_line[idx] = ' ';
  // truncate the command line string up to the last non-space character
  cmd_line[str.find_last_not_of(WHITESPACE, idx) + 1] = 0;
}

// TODO: Add your implementation for classes in Commands.h

char** getCmdArgs(const char* cmd_line, int *numOfArgs)
{
    char** argsArray = (char**) malloc(COMMAND_MAX_ARGS);
    if(!argsArray)
    {
        return nullptr;
    }
    for(int i = 0; i < COMMAND_MAX_ARGS; i++)
    {
        argsArray[i] = nullptr;
    }
    *numOfArgs = _parseCommandLine(cmd_line,argsArray);
    return argsArray;
}

bool checkIfNumber(const char* input)
{
    while(*input != '\0')
    {
        if(!isdigit(*input))
        {
            return false;
        }
        input++;
    }
    return true;
}

void freeCmdArgs(char** args)
{
    for(int i = 0; i < COMMAND_MAX_ARGS; i++)
    {
        free(args[i]);
    }
    delete[] args;
}

Command::Command(const char *cmd_line):cmdline(cmd_line){}

BuiltInCommand::BuiltInCommand(const char *cmd_line) : Command(cmd_line)
{

}

ChangePromptCommand::ChangePromptCommand(const char *cmd_line) : BuiltInCommand(cmd_line)
{
}

void ChangePromptCommand::execute(){
    int num_of_args;
    char** args = getCmdArgs(this->cmdline,&num_of_args);
    if(args == nullptr)
    {
        perror("smash error: malloc failed");
        return;
    }
    SmallShell &shell = SmallShell::getInstance();
    if(num_of_args == 1)
    {
        shell.prompt = "smash";
    }
    else
    {
        shell.prompt = args[1];
    }
    for(int i = 0; i < COMMAND_ARGS_MAX_LENGTH; i++)
    {
        free(args[i]);
    }
    free(args);
}

ShowPidCommand::ShowPidCommand(const char *cmd_line) : BuiltInCommand(cmd_line)
{}

void ShowPidCommand::execute()
{
    SmallShell &smash = SmallShell::getInstance();
    cout << "smash pid is " << smash.shell_pid << endl;
}

GetCurrDirCommand::GetCurrDirCommand(const char *cmd_line): BuiltInCommand(cmd_line)
{}

void GetCurrDirCommand::execute()
{
    char* buffer = new char[WD_MAX_LENGTH+1];
    if(getcwd(buffer, WD_MAX_LENGTH+1) == nullptr)
    {
        delete[] buffer;
        perror("CWD size exceeds limit");
        return;
    }
    cout << buffer << endl;
    delete[] buffer;
}

ChangeDirCommand::ChangeDirCommand(const char *cmd_line, char **plastPwd) : BuiltInCommand(cmd_line), last_wd(plastPwd)
{}

void ChangeDirCommand::execute()
{
    int num_of_args;
    char** args = getCmdArgs(cmdline,&num_of_args);
    if(num_of_args > 2)
    {
        perror("smash error: cd: too many arguments"); //TODO
        return;
    }
    if(num_of_args == 1) //TODO
    {
        perror("smash error: cd: no arguments specified");
        return;
    }
    if(strcmp(args[1],"-") == 0)
    {
        SmallShell &smash = SmallShell::getInstance();
        if(!(*last_wd))
        {
            perror("smash error: cd: OLDPWD not set");
        }
        if(chdir(*last_wd) == -1)
        {
            perror("smash error: chdir failed");
        }
    }
}

JobsCommand::JobsCommand(const char *cmd_line, JobsList *jobs) : BuiltInCommand(cmd_line), jobs(jobs)
{}

void JobsCommand::execute()
{
    jobs->removeFinishedJobs();
    jobs->printJobsList();
}

ForegroundCommand::ForegroundCommand(const char *cmd_line, JobsList *jobs) : BuiltInCommand(cmd_line), jobs(jobs)
{}

void ForegroundCommand::fgHelper(JobsList::JobEntry* job)
{
    if(job->stopped)
    {
        if (kill(job->pid, SIGCONT) == -1)
        {
            perror("smash error: kill failed");
            return;
        }
    }
    cout << cmdline << " : " << job->pid << endl;

    SmallShell& smash = SmallShell::getInstance();
    smash.fg_cmdline = cmdline;
    smash.fg_job_id = job->job_id;
    smash.fg_pid = job->pid;
    jobs->removeJobById(job->job_id);
    if(waitpid(job->pid, nullptr, WUNTRACED) == -1) //TODO check if WUNTRACED is needed
    {
        perror("smash error: waitpid failed");
        return;
    }
}

void ForegroundCommand::execute()
{
    int num_of_args;
    char** args = getCmdArgs(cmdline,&num_of_args);
    if(num_of_args > 2)
    {
        perror("smash error: fg: invalid arguments");
        freeCmdArgs(args);
        return;
    }
    if(num_of_args == 2)
    {
        if(!checkIfNumber(args[1]))
        {
            perror("smash error: fg: invalid arguments");
            freeCmdArgs(args);
            return;
        }
        JobsList::JobEntry* job = jobs->getJobByID(stoi(args[1]));
        if(!job)
        {
            cerr << "smash error: fg: job-id " << args[1] << " does not exist" << endl;
            freeCmdArgs(args);
            return;
        }
        fgHelper(job);
    }
    if(num_of_args == 1)
    {
        if(jobs->jobs_list.empty())
        {
            perror("smash error: fg: jobs list is empty");
            freeCmdArgs(args);
            return;
        }
        JobsList::JobEntry* job = jobs->getLastJob();
        fgHelper(job);
    }
    freeCmdArgs(args);
}

void BackgroundCommand::bgHelper(JobsList::JobEntry* job){
    if (kill(job->pid, SIGCONT) == -1)
    {
        perror("smash error: kill failed");
        return;
    }
    job->stopped = false;
    cout << cmdline << " : " << job->pid << endl;
}

void BackgroundCommand::execute()
{
    int num_of_args;
    char** args = getCmdArgs(cmdline,&num_of_args);
    if(num_of_args > 2)
    {
        perror("smash error: bg: invalid arguments");
        freeCmdArgs(args);
        return;
    }
    if(num_of_args == 2)
    {
        if (!checkIfNumber(args[1]))
        {
            perror("smash error: bg: invalid arguments");
            freeCmdArgs(args);
            return;
        }
        JobsList::JobEntry* job = jobs->getJobByID(stoi(args[1]));
        if(!job)
        {
            cerr << "smash error: bg: job-id " << args[1] << " does not exist" << endl;
            freeCmdArgs(args);
            return;
        }
        if(!job->stopped) //if running in bg
        {
            cerr << "smash error: bg: job-id " << job->job_id << "is already running in the background" << endl;
            freeCmdArgs(args);
            return;
        }
        bgHelper(job);
    }
    if(num_of_args == 1)
    {
        JobsList::JobEntry* last_stopped = jobs->getLastStoppedJob();
        if(last_stopped == nullptr)
        {
            perror("smash error: bg: there is no stopped jobs to resume");
            freeCmdArgs(args);
            return;
        }
        bgHelper(last_stopped);
    }
    freeCmdArgs(args);
}

QuitCommand::QuitCommand(const char *cmd_line, JobsList *jobs) : BuiltInCommand(cmd_line), jobs(jobs)
{}

void QuitCommand::execute()
{
    int num_of_args;
    char** args = getCmdArgs(cmdline,&num_of_args);
    if(num_of_args > 1 && strcmp(args[1], "kill") == 0)
    {
        jobs->killAllJobs();
    }
    freeCmdArgs(args);
    exit(0);
}

KillCommand::KillCommand(const char *cmd_line, JobsList *jobs) : BuiltInCommand(cmd_line), jobs(jobs)
{
}



void KillCommand::execute()
{
    int num_of_args;
    char** args = getCmdArgs(cmdline,&num_of_args);
    char* first_arg = &args[1][1];
    if(num_of_args != 3)
    {
        perror("smash error: kill: invalid arguments");
        freeCmdArgs(args);
        return;
    }
    string signal = string (args[1]).substr(1, string (args[1]).size());
    if(args[1][0] != '-' || !checkIfNumber(signal.c_str()) ||
            !checkIfNumber(args[2]))
    {
        perror("smash error: kill: invalid arguments");
        freeCmdArgs(args);
        return;
    }
    JobsList::JobEntry* job = jobs->getJobByID(stoi(args[2]));
    if(job == nullptr)
    {
        cerr << "smash error: kill: job-id " << args[2] <<" does not exist" << endl;
        freeCmdArgs(args);
        return;
    }
    if(kill(job->pid, stoi(signal) == -1))
    {
        perror("smash error: kill failed");
        freeCmdArgs(args);
        return;
    }
    if(stoi(signal) == SIGCONT)
    {
        job->stopped = false;
    }
    if(stoi(signal) == SIGSTOP)
    {
        job->stopped = true;
    }
    cout << "signal number " << signal << " was sent to pid " << job->pid << endl;
}

SmallShell::SmallShell()
{
    prompt = "smash";
    fg_pid; //TODO to init or not?
    fg_cmdline; //
    fg_job_id; //
}

SmallShell::~SmallShell() {
// TODO: add your implementation
}

/**
* Creates and returns a pointer to Command class which matches the given command line (cmd_line)
*/
Command * SmallShell::CreateCommand(const char* cmd_line) {
	// For example:
/*
  string cmd_s = _trim(string(cmd_line));
  string firstWord = cmd_s.substr(0, cmd_s.find_first_of(" \n"));

  if (firstWord.compare("pwd") == 0) {
    return new GetCurrDirCommand(cmd_line);
  }
  else if (firstWord.compare("showpid") == 0) {
    return new ShowPidCommand(cmd_line);
  }
  else if ...
  .....
  else {
    return new ExternalCommand(cmd_line);
  }
  */
  return nullptr;
}

void SmallShell::executeCommand(const char *cmd_line) {
  // TODO: Add your implementation here
  // for example:
  // Command* cmd = CreateCommand(cmd_line);
  // cmd->execute();
  // Please note that you must fork smash process for some commands (e.g., external commands....)
}

//TODO JobsList Functions:

JobsList::JobsList(): nextJobID(1), jobs_list()
{
}

JobsList::JobEntry::JobEntry(bool stopped, int job_id, const char* cmd_line, pid_t pid):finished(false),stopped(stopped),job_id(job_id), time_added(-1), cmd_line(cmd_line), pid(pid)
{}

void JobsList::addJob(Command *cmd, pid_t pid, bool isStopped)
{
    JobsList::removeFinishedJobs();
    JobEntry new_job(isStopped,nextJobID, cmd->cmdline, pid);
    nextJobID++;
    new_job.time_added = time(nullptr);
    jobs_list.push_back(new_job);

}

void JobsList::printJobsList() //TODO check space validity
{
    for(const auto& job : jobs_list)
    {
        if(!job.finished)
        {
            if (!job.stopped)
            {
                cout << "[" << job.job_id << "]" << job.cmd_line << " : " << job.pid << " "
                     << (int) difftime(job.time_added,
                                       time(nullptr)) << " secs" << endl;
            }
            else
            {
                cout << "[" << job.job_id << "]" << job.cmd_line << " : " << job.pid << " "
                     << (int) difftime(job.time_added,
                                       time(nullptr)) << " secs (stopped)" << endl;
            }
        }
    }
}

void JobsList::removeFinishedJobs()
{
    jobs_list.remove_if([](JobEntry job) {return job.finished;}); //TODO check validity
}

JobsList::JobEntry* JobsList::getJobByID(int jobId)
{
    for(auto& job : jobs_list)
    {
        if(job.job_id == jobId)
        {
            return &job;
        }
    }
    return nullptr;
}

void JobsList::removeJobById(int jobId)
{
    jobs_list.remove_if([&jobId](JobEntry job) {if(job.job_id == jobId) return true;}); //TODO check validity
}

JobsList::JobEntry *JobsList::getLastJob()
{
    return &jobs_list.back();
}

JobsList::JobEntry* JobsList::getLastStoppedJob()
{
    JobEntry* last_stopped = nullptr;

    for(auto& job : jobs_list)
    {
        if(job.stopped)
        {
            last_stopped = &job;
        }
    }
    return last_stopped;
}

void JobsList::killAllJobs()
{
    cout << " sending SIGKILL signal to "<< jobs_list.size() << " jobs" << endl;
    for(auto& job : jobs_list)
    {
        cerr << job.pid << ": " << job.cmd_line << endl;
    }
    for(auto& job : jobs_list)
    {

        if(kill(job.pid,SIGKILL) == -1)
        {
            perror("smash error: kill failed");
            return;
        }
    }
}

